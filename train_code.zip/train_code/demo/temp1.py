import torch

while 1:
    a = torch.ones(1000, 1000)
    a = a*a