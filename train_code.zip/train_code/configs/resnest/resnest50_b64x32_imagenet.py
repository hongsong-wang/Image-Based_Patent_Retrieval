_base_ = 'resnest50_32xb64_in1k.py'

_deprecation_ = dict(
    expected='resnest50_32xb64_in1k.py',
    reference='https://github.com/open-mmlab/mmclassification/pull/508',
)
