_base_ = 'resnest200_64xb32_in1k.py'

_deprecation_ = dict(
    expected='resnest200_64xb32_in1k.py',
    reference='https://github.com/open-mmlab/mmclassification/pull/508',
)
