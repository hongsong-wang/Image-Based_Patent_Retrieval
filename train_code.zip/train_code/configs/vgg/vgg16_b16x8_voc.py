_base_ = 'vgg16_8xb16_voc.py'

_deprecation_ = dict(
    expected='vgg16_8xb16_voc.py',
    reference='https://github.com/open-mmlab/mmclassification/pull/508',
)
