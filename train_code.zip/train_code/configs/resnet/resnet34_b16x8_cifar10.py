_base_ = 'resnet34_8xb16_cifar10.py'

_deprecation_ = dict(
    expected='resnet34_8xb16_cifar10.py',
    reference='https://github.com/open-mmlab/mmclassification/pull/508',
)
