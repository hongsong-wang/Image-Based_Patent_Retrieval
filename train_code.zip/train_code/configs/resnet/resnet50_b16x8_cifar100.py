_base_ = 'resnet50_8xb16_cifar100.py'

_deprecation_ = dict(
    expected='resnet50_8xb16_cifar100.py',
    reference='https://github.com/open-mmlab/mmclassification/pull/508',
)
