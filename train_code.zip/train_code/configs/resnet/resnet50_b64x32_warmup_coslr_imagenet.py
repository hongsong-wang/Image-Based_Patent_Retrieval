_base_ = 'resnet50_32xb64-warmup-coslr_in1k.py'

_deprecation_ = dict(
    expected='resnet50_32xb64-warmup-coslr_in1k.py',
    reference='https://github.com/open-mmlab/mmclassification/pull/508',
)
