_base_ = 'resnext152-32x4d_8xb32_in1k.py'

_deprecation_ = dict(
    expected='resnext152-32x4d_8xb32_in1k.py',
    reference='https://github.com/open-mmlab/mmclassification/pull/508',
)
